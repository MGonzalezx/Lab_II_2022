﻿public enum EPais
{
    Argentina,
    China,
    Holanda,
    USA,
    Corea
}

public enum ETipo
{
    Tubo,
    Plasma,
    Led
}

public enum EGama
{
    Baja,
    Media,
    Alta
}

public enum EProducto
{
    PrecioDeTelevisores,
    PrecioDeCelulares,
    PrecioTotal
}