﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinFormsApp
{
    ///Agregar manejo de excepciones en TODOS los lugares críticos!!!

    public delegate void DelegadoThreadConParam(object param);

    public partial class FrmPrincipal : Form
    {
        protected Task hilo;
        protected CancellationTokenSource cts;

        public FrmPrincipal()
        {
            InitializeComponent();
            this.WindowState = FormWindowState.Maximized;
        }

        private void FrmPrincipal_Load(object sender, EventArgs e)
        {
            this.Text = "Gonzalez,Martin";
            MessageBox.Show(this.Text);         
        }

        ///
        /// CRUD
        ///
        private void listadoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FrmListado frm = new FrmListado();
            frm.StartPosition = FormStartPosition.CenterScreen;

            frm.Show(this);
        }

        ///
        /// VER LOG
        ///
        private void verLogToolStripMenuItem_Click(object sender, EventArgs e)
        {

            DialogResult rta = DialogResult.Cancel;///Reemplazar por la llamada al método correspondiente del OpenFileDialog

            if (rta == DialogResult.OK)
            {
                /// Mostrar en txtUsuariosLog.Text el contenido del archivo .log
            }
            else
            {
                MessageBox.Show("No se muestra .log");
            }
        }

        ///
        /// DESERIALIZAR JSON
        ///
        private void deserializarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            List<Entidades.Final.Usuario> listado = null;
            string path = ""; /// Reemplazar por el path correspondiente

            bool todoOK = false; /// Reemplazar por la llamada al método correspondiente de Manejadora

            if (todoOK)
            {
                this.txtUsuariosLog.Clear();

                /// Mostrar en txtUsuariosLog.Text el contenido de la deserialización.
            }
            else
            {
                MessageBox.Show("NO se pudo deserializar a JSON");
            }

        }

        ///
        /// TASK
        ///
        private void taskToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.cts = new CancellationTokenSource();
            ///Se inicia el hilo.
            this.hilo = null; /// inicializar tarea
            ///Se desasocia al manejador de eventos.
            this.taskToolStripMenuItem.Click -= new EventHandler(this.taskToolStripMenuItem_Click);
        }


        ///PARA ACTUALIZAR LISTADO DESDE BD EN HILO
        public void ActualizarListadoUsuarios(object param)
        {
            /// Implementar...

        }

        private void FrmPrincipal_FormClosing(object sender, FormClosingEventArgs e)
        {
            ///CANCELAR HILO
            this.cts.Cancel();
        }
    }
}
