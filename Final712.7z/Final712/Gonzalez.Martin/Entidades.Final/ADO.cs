﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;

namespace Entidades.Final
{
    public delegate void ApellidoUsuarioExistenteDelegado(List<Usuario> lista);
    public class ADO
    {
        static string conexion;
        static SqlCommand comando;
        static SqlConnection conexionSql;
        public event ApellidoUsuarioExistenteDelegado ApellidoUsuarioExistente;
        private ADO()
        {
            conexion = @"Server=sa;Database=laboratorio_2;Trusted_Connection=True;";
            comando = new SqlCommand();
            conexionSql = new SqlConnection(conexion);
            comando.Connection = conexionSql;
            comando.CommandType = System.Data.CommandType.Text;
        }

        public bool Agregar(Usuario user)
        {
            bool retorno = false;
            try
            {
                comando.CommandText = "Insert into usuarios values (nombre, apellido, dni, correo, clave)";
                comando.Parameters.Clear();
                comando.Parameters.AddWithValue("nombre", user.Nombre);
                comando.Parameters.AddWithValue("apellido", user.Apellido);
                comando.Parameters.AddWithValue("dni", user.Dni);
                comando.Parameters.AddWithValue("correo", user.Correo);
                comando.Parameters.AddWithValue("clave", user.Clave);

                if (conexionSql.State != ConnectionState.Open)
                {
                    conexionSql.Open();
                }
                retorno = true;

                
            }
            catch (Exception e)
            {
                throw e;
            }

            return retorno;
        }

        public bool Eliminar(Usuario user)
        {
            bool retorno = false;
            try
            {
                comando.Parameters.Clear();
                conexionSql.Open();
                comando.CommandText = $"DELETE FROM usuarios WHERE dni = @dni";
                comando.Parameters.AddWithValue("@dni", user.Dni);
                comando.ExecuteNonQuery();


                retorno = true;

            }
            catch (Exception ex)
            {
               throw ex;
            }
            finally
            {
                conexionSql.Close();
            }
            return retorno;
        }

        public bool Modificar(Usuario user)
        {
            bool retorno = false;
            try
            {
                comando.Parameters.Clear();
                conexionSql.Open();
                comando.CommandText = $"UPDATE usuarios SET nombre = @Nombre, apellido = @Apellido, dni = @Dni, correo = @Correo, clave = @Clave WHERE dni = {user.Dni}";
                comando.Parameters.AddWithValue("@Nombre", user.Nombre);
                comando.Parameters.AddWithValue("@Apellido", user.Apellido);
                comando.Parameters.AddWithValue("@Dni", user.Dni);
                comando.Parameters.AddWithValue("@Correo", user.Correo);
                comando.Parameters.AddWithValue("@Clave", user.Clave);
        
                comando.ExecuteNonQuery();


                retorno = true;

            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                conexionSql.Close();
            }
            return retorno;
        }

        public static List<Usuario> ObtenerTodos()
        {
            List<Usuario> usuarios = new List<Usuario>();

            try
            {

                comando.Parameters.Clear();
                conexionSql.Open();


                comando.CommandText = $"SELECT nombre as Nombre, apellido as apellido, dni as Dni, " +
                    $"correo as Correo, clave as Clave FROM usuarios";



                using (SqlDataReader dataReader = comando.ExecuteReader())
                {
                    while (dataReader.Read())
                    {



                        usuarios.Add(new Usuario(dataReader["Nombre"].ToString(), dataReader["Apellido"].ToString(), Convert.ToInt32(dataReader["Dni"]), dataReader["Correo"].ToString(),
                            dataReader["Clave"].ToString()));



                    }
                }


            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                conexionSql.Close();
            }

            return usuarios;
        }

        public static List<Usuario> ObtenerTodos(string apellidoUsuario)
        {
            List<Usuario> usuarios = new List<Usuario>();

            try
            {

                comando.Parameters.Clear();
                conexionSql.Open();


                comando.CommandText = $"SELECT nombre as Nombre, apellido as apellido, dni as Dni, " +
                    $"correo as Correo, clave as Clave FROM usuarios WHERE apellido = {apellidoUsuario} ";



                using (SqlDataReader dataReader = comando.ExecuteReader())
                {
                    while (dataReader.Read())
                    {



                        usuarios.Add(new Usuario(dataReader["Nombre"].ToString(), dataReader["Apellido"].ToString(), Convert.ToInt32(dataReader["Dni"]), dataReader["Correo"].ToString(),
                            dataReader["Clave"].ToString()));



                    }
                }


            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                conexionSql.Close();
            }

            return usuarios;
        }

    }
}

