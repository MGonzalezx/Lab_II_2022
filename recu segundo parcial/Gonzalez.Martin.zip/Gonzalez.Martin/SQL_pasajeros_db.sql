USE [pasajeros_db]
GO

INSERT INTO [dbo].[pasajeros]
           ([dni]
           ,[nombre]
           ,[equipaje])
     VALUES
        (39785695, 'Robina', 8),   			 
		(31729108, 'Humfried', 15),
		(52602132, 'Gretel', 2),
		(50727015, 'Lewiss', 4),
		(39604870, 'Lock', 5),
		(44065585, 'Caryn',	2),
		(35649621, 'Janessa', 13),
		(39347297, 'Neil', 9),
		(38048733, 'Dennie', 11),
		(30956168, 'Abbott', 2);

GO


