﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;

namespace Entidades.RSP
{
    public static class Extensora
    {
        private static string conexion;
       

        static Extensora()
        {
            conexion = (@"Data Source=.;Database=pasajeros_db;Trusted_Connection=True;");

            

        }

        /*public static List<Pasajero> ObtenerTodos(BD)
        {

        }*/
    }
}
